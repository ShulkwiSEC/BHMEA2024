const dataStore = {
    users: [],
    orders: []
  };
  
  module.exports = dataStore;