#!/bin/bash
sed -i "s/nodev:true/nodev:true  rw:true/" /tmp/nsjail.cfg
